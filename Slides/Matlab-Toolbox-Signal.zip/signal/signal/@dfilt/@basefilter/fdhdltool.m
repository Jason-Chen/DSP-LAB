function fdhdltool(filterobj)
%FDHDLTOOL Launch the GUI to generate HDL
%   FDHDLTOOL(Hb) launches the Generate HDL dialog that lets you
%   customize and generate Verilog or VHDL code and test benches for a copy
%   of the quantized filter, Hb. You have to call FDHDLTOOL again if
%   you make changes in the filter, Hb at the command line. 
%
%   The main dialog and two subordinate dialogs provide access to many
%   options for customizing the generated filter and test bench code.
%
%   The Generate HDL main dialog categorizes options in two frames:
% 
%   * HDL Filter - Options you are most likely to customize at least once:
%   language selection, name and location of generated files, reset
%   specifications, and optimizations. 
% 
%   * Test bench types - Options for naming and specifying the type of test
%   bench files to generate, and specific types of stimuli the test benches
%   are to apply.
%
%   Example:
%   ========
%   filtdes = fdesign.lowpass('N,Fc,Ap,Ast',30,0.4,0.05,0.03,'linear');
%   Hb = design(filtdes,'filterstructure','dffir');
%   Hb.arithmetic = 'fixed';
%   fdhdltool(Hb);
%
%   See also GENERATEHDL, GENERATETB, GENERATETBSTIMULUS.

%   Copyright 2006 The MathWorks, Inc.
%   $Revision: 1.1.8.2 $  $Date: 2007/04/09 19:05:05 $

[cando, errstr] = ishdlable(filterobj);
if ~cando
    error(generatemsgid('unsupportedarch'), errstr);
end

if ~isempty(inputname(1)), % when handle to filterobj is passed
    % make a copy and change the names in the widgets
    filtercopy = copy(filterobj);
    hdlg = hdlgui.createhdldlg(filtercopy);
    filterName = [inputname(1), '_copy'];
    htest = find(hdlg, '-isa', 'hdlgui.vhdltestbench');
    set(htest, 'TestBenchName', sprintf('%s_tb', filterName));
    hlang = find(hdlg, '-isa', 'hdlgui.language');
    set(hlang, 'Name', sprintf('%s', filterName));
else % when constructor is passed directly
   hdlgui.createhdldlg(filterobj); % the default name 'filter' is used internally
end  
% [EOF]
