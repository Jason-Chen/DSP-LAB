function varargout = block(Hd, varargin)
%BLOCK Generate a Signal Processing Blockset block equivalent to the filter object.
%   BLOCK(Hd) generates a Signal Processing Blockset block equivalent to Hd.
%
%   BLOCK(Hd, PARAMETER1, VALUE1, PARAMETER2, VALUE2, ...) generates a
%   Signal Processing Blockset block using the options specified in the
%   parameter/value pairs. The available parameters are:
%
%     -------------       ---------------      ----------------------------
%     Property Name       Property Values      Description
%     -------------       ---------------      ----------------------------
%     Destination         [{'current'}         Specify whether to add the block
%                          'new'               to your current Simulink model,
%                          <user defined>]     create a new model to contain the
%                                              block, or specify the name of the
%                                              target subsystem. 
%
%     Blockname           {'filter'}           Provides the name for the new 
%                                              subsystem block. By default the 
%                                              block is named 'filter'.
%
%     OverwriteBlock      ['on' {'off'}]       Specify whether to overwrite an
%                                              existing block with the same name
%                                              as specified by the Blockname 
%                                              property or create a new block.
%
%     MapStates           ['on' {'off'}]       Specify whether to map the States
%                                              of the filter as initial conditions
%                                              of the block.
%
%     Link2Obj            ['on' {'off'}]       Specify whether to set the
%                                              filter variable in the block
%                                              mask rather than setting the
%                                              coefficient values.
%
%    EXAMPLES:
%    [b,a] = butter(5,.5);
%    Hd = dfilt.df1(b,a);
% 
%    %#1 Default syntax:
%    block(Hd);
% 
%    %#2 Using parameter/value pairs:
%    block(Hd, 'Blockname', 'DF1');

%   Author(s): V. Pellissier
%   Copyright 1988-2008 The MathWorks, Inc.
%   $Revision: 1.2.4.14 $  $Date: 2008/04/21 16:29:59 $

% Check if Signal Processing Blockset is installed
[b, errstr, errid] = isspblksinstalled;
if ~b
    error(generatemsgid(errid), errstr);
end

mapstates = 'off';
idx = find(strcmpi(varargin,'MapStates'));
if ~isempty(idx), mapstates = varargin{idx+1}; end
link2obj = 'off';
idx = find(strcmpi(varargin,'Link2Obj'));
if ~isempty(idx), link2obj = varargin{idx+1}; end

isfixpt = isfield(get(Hd),'Arithmetic') && strcmpi(get_arith(Hd),'fixed');
if (isfixpt && strcmpi(link2obj,'on'))
    msgid = generatemsgid('fixedpointLink2obj');    
    warning(msgid,'Changes in InputWordlength and InputFracLength will be ignored by the block.');
end
    
try
     [lib srcblk s] = superblockparams(Hd, mapstates, link2obj, inputname(1));
catch ME
     throw(ME);
end

% Parse inputs
[hTar, msg] = parse_inputs(Hd, varargin{:});
if ~isempty(msg), error(generatemsgid('SigErr'),msg); end

% If a block handle was passed in, use it, else add it from the Simulink
% system from [lib '/' srcblk]
if ~isempty(hTar.BlockHandle) && ishandle(hTar.BlockHandle),
    pos = [];
    isloaded = false;
    h = hTar.blockHandle;
    set_param(h,'Tag','BlockMethodSubSystem');
else
    % Create model
    pos = createmodel(hTar);

    isloaded = lclload_system(lib);
    sys = hTar.system;
    sysname = hTar.blockname;

    % Find the sys path
    slindex = findstr(sys,'/');
    syspath = sys(1:slindex(end)-1);

    if strcmpi(hTar.OverwriteBlock, 'on') %
        currentblk = find_system(syspath, 'SearchDepth', 1,'LookUnderMasks', 'all', 'Name', sysname);
        if ~isempty(currentblk)
            delete_block(currentblk{1});% Delete Filter block if present in the Destination
        end
    end
    
    % Check whether the filter arithmetic is fixed point.
    if(isfixpt)
        load_system('simulink');
        
        h = add_block('built-in/subsystem',hTar.system,'Tag','BlockMethodSubSystem');        
        h1 = add_block('built-in/Inport',[hTar.System '/In']);
        h2 = add_block('simulink/Signal Attributes/Data Type Conversion',[hTar.System '/Input Quantizer']);
        h3 = add_block([lib '/' srcblk], [hTar.system '/filter']);
        h4 = add_block('built-in/Outport',[hTar.System '/Out']);
        
        set_param(h1,'Position',[20 45 60 65]);
        set_param(h2,'Position',[110 40 150 70]);
        set_param(h3,'Position',[200 35 270 75]);
        set_param(h4,'Position',[320 45 360 65]);

        add_line(hTar.system,'In/1','Input Quantizer/1')
        add_line(hTar.system,'Input Quantizer/1','filter/1')
        add_line(hTar.system,'filter/1','Out/1')
        
        close_system('simulink');

    else
        h = add_block([lib '/' srcblk], hTar.system, 'Tag', 'BlockMethodSubSystem');
    end
    
    % Refresh connections
    oldpos = get_param(sys, 'Position');
    set_param(sys, 'Position', oldpos + [0 -5 0 -5]);
    set_param(sys, 'Position', oldpos);
    
    % Open system
    syspath = sys(1:slindex(1)-1);

    open_system(syspath);
end

% Set Filter parameters
if(isfixpt)
    iwl = Hd.inputWordLength;
    ifl = Hd.InputFracLength;
    outdatatype = strcat('sfix(',num2str(iwl),')');
    outscaling = strcat('2^',num2str(-ifl));
    rndmeth = 'Nearest';
    set_param(h2, ...
        'OutDataTypeMode','Specify via Dialog', ...
        'OutDataType',outdatatype, ...
        'OutScaling',outscaling, ...
        'LockScale','off', ...
        'RndMeth', rndmeth, ...
        'DoSatur','on');
    fldnames = fieldnames(s);
    for i=1:length(fldnames),
        set_param(h3, fldnames{i}, s.(fldnames{i}));
    end    
else   
    fldnames = fieldnames(s);
    for i=1:length(fldnames),
        set_param(h, fldnames{i}, s.(fldnames{i}));
    end
end      

if ~isempty(pos), set_param(h, 'Position', pos); end

if isloaded,
    close_system(lib);
end

if nargout,
    varargout = {h};
end

%-----------------------------------------------------------
function isloaded = lclload_system(name)

isloaded = false;

% We don't need to load the built-in library blocks.
if strcmpi(name, 'built-in')
    return;
end

if isempty(find_system(0,'Name', name)),
    isloaded = true;
    w=warning;
    warning('off');
    load_system(name);
    warning(w);
end

%------------------------------------------------------------
function [hTar, msg] = parse_inputs(Hd, varargin)

msg ='';
if nargin==1,
    % Create a default parameter object
     hParam = dspfwiz.parameter(Hd,'block');
elseif nargin==2,
    % Use the parameter object passed as input
    hParam = varargin{1};
else
    % Set p-v pairs of the parameter object
     hParam = dspfwiz.parameter(Hd,'block');
    try
        for i=1:2:nargin-2,
            set(hParam, varargin{i}, varargin{i+1});            
        end 
    catch ME
        msg = ME.message; 
    end
end

hTar = get(hParam, 'targetObj');

% [EOF]
