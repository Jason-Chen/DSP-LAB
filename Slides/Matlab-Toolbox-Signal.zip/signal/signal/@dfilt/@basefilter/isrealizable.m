function b = isrealizable(this)
%ISREALIZABLE   Return whether the object is realizable.

%   Author(s): J. Schickler
%   Copyright 1988-2004 The MathWorks, Inc.
%   $Revision: 1.1.6.1 $  $Date: 2004/02/09 08:41:39 $

b = true;

% [EOF]
