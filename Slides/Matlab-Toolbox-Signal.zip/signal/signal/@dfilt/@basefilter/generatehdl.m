function generatehdl(filterobj, varargin)
%GENERATEHDL Generate HDL.

%   Copyright 2003-2006 The MathWorks, Inc.
%   $Revision: 1.1.6.6 $  $Date: 2006/12/27 21:29:49 $ 

  [cando, errstr] = ishdlable(filterobj);
  if ~cando
    error(generatemsgid('unsupportedarch'), errstr);
  end

  % Add filter object variable name to varargin 
  if ~any(strcmpi(varargin,'name'))
    varargin(end+1) = {'name'};
    if ~isempty(inputname(1))
        varargin(end+1) = {inputname(1)};
    else
        error(generatemsgid('genhdlcalledwithconst'), 'First argument of ''generatehdl'' command must be handle of a filter object.');
    end
  end
  
  privgeneratehdl(filterobj,varargin{:});

% [EOF]

