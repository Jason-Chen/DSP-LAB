function s = base_savepublicinterface(this)
%BASE_SAVEPUBLICINTERFACE   

%   Author(s): J. Schickler
%   Copyright 1988-2004 The MathWorks, Inc.
%   $Revision: 1.1.6.1 $  $Date: 2004/12/26 22:03:28 $

s.PersistentMemory    = this.PersistentMemory;
s.NumSamplesProcessed = this.NumSamplesProcessed;

% [EOF]
