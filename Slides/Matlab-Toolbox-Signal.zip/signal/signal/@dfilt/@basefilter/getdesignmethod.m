function designmethod = getdesignmethod(this)
%GETDESIGNMETHOD   Get the designmethod.

%   Author(s): R. Losada
%   Copyright 2005 The MathWorks, Inc.
%   $Revision: 1.1.6.1 $  $Date: 2005/11/18 14:23:40 $

designmethod = this.privdesignmethod;

% [EOF]
