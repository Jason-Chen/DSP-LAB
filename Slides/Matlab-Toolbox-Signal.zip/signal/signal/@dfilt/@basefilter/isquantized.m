function b = isquantized(this)
%ISQUANTIZED   Returns true if it is a QFILT or a quantized DFILT.

%   Author(s): J. Schickler
%   Copyright 1988-2003 The MathWorks, Inc.
%   $Revision: 1.1.6.2 $  $Date: 2004/04/12 23:52:59 $

% Use BASE_IS to add vector support.
b = base_is(this, 'thisisquantized');

% [EOF]
