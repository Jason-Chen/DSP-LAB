function logi = isparallelfilterable(this)
%ISPARALLELFILTERABLE   

%   Author(s): R. Losada
%   Copyright 1988-2004 The MathWorks, Inc.
%   $Revision: 1.1.6.1 $  $Date: 2004/01/25 23:02:55 $

logi = false;

% [EOF]
