function s = base_saveprivatedata(this)
%BASE_SAVEPRIVATEDATA   

%   Author(s): J. Schickler
%   Copyright 2004-2005 The MathWorks, Inc.
%   $Revision: 1.1.6.3 $  $Date: 2005/06/30 17:33:16 $

s = [];

% [EOF]
