function varargout = basefilter(varargin)
%BASEFILTER Constructor for this class.

%   Author: V. Pellissier
%   Copyright 1988-2003 The MathWorks, Inc.
%   $Revision: 1.1.4.3 $  $Date: 2007/12/14 15:07:18 $

error(generatemsgid('AbstractClass'),'This is an abstract class.');

% [EOF]
