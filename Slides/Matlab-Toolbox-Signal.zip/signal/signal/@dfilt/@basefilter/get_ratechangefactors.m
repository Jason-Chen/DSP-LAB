function ratechangefactors = get_ratechangefactors(this, ratechangefactors)
%GET_RATECHANGEFACTORS   PreGet function for the 'ratechangefactors' property.

%   Author(s): J. Schickler
%   Copyright 1988-2004 The MathWorks, Inc.
%   $Revision: 1.1.6.1 $  $Date: 2004/04/01 16:18:28 $

% NO OP.

% [EOF]
