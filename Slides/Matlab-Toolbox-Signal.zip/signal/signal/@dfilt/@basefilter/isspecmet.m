function b = isspecmet(this, varargin)
%ISSPECMET   True if the object's specification has been met by the filter.

%   Author(s): J. Schickler
%   Copyright 2005 The MathWorks, Inc.
%   $Revision: 1.1.8.1 $  $Date: 2005/06/16 08:17:45 $

m = measure(this);

if isempty(m)
    b = false;
else
    b = isspecmet(m);
end

% [EOF]
