function pnames = basefilterprivnames(this)
%BASEFILTERPRIVNAMES   

%   Author(s): R. Losada
%   Copyright 2003-2004 The MathWorks, Inc.
%   $Revision: 1.1.6.3 $  $Date: 2004/12/26 22:03:30 $

pnames = {'PersistentMemory','NumSamplesProcessed','privRateChangeFactor'};

% [EOF]
