function varargout = phasez(Hb,varargin)
%PHASEZ Phase response of a discrete-time filter.
%   This method is obsolete.  Use PHASE instead.

%   Author: V. Pellissier
%   Copyright 1988-2004 The MathWorks, Inc.
%   $Revision: 1.4.4.2 $  $Date: 2005/06/16 08:17:49 $

% siguddutils('obsoletemethod', 'phase');

if nargout,
    
    % Strings are faster than Function Handles
    [Ph, w] = base_resp(Hb, 'computephasez', varargin{:});
    varargout = {Ph, w};
else,    
    [Hb, opts] = freqzparse(Hb, varargin{:});
    fvtool(Hb, 'phase', opts);
end

% [EOF]
