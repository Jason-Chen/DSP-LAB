function varargout = grpdelay(Hb,varargin)
%GRPDELAY Group delay of a discrete-time filter.
%   This method is obsolete.  Use GROUPDELAY instead.

%   Author: V. Pellissier, J. Schickler
%   Copyright 1988-2004 The MathWorks, Inc.
%   $Revision: 1.3.4.2 $  $Date: 2005/06/16 08:17:42 $

% siguddutils('obsoletemethod', 'groupdelay');

if nargout,
    [Gd, w] = base_resp(Hb, 'computegrpdelay', varargin{:});
    varargout = {Gd, w};
else,
    [Hb, opts] = freqzparse(Hb, varargin{:});
    fvtool(Hb, 'grpdelay', opts);    
end

% [EOF]
