function privfdesign = get_privfdesign(this, privfdesign)
%GET_PRIVFDESIGN   PreGet function for the 'privfdesign' property.

%   Author(s): R. Losada
%   Copyright 1988-2005 The MathWorks, Inc.
%   $Revision: 1.1.6.2 $  $Date: 2005/12/22 18:56:59 $



% [EOF]
