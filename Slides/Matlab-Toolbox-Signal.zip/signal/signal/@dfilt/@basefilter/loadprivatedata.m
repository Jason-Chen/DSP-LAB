function loadprivatedata(this, s)
%LOADPRIVATEDATA   Load the private data.

%   Author(s): J. Schickler
%   Copyright 1988-2004 The MathWorks, Inc.
%   $Revision: 1.1.6.2 $  $Date: 2005/04/04 16:58:41 $

base_loadprivatedata(this, s);

% [EOF]
