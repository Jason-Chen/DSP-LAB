function temphdlsettopprops(this, hF)
%TEMPHDLSETTOPPROPS A temperory method - will be removed once
%rationalization of properties is complete
%   OUT = TEMPHDLSETTOPPROPS(ARGS) <long description>

%   Copyright 2007 The MathWorks, Inc.
%   $Revision: 1.1.6.2 $  $Date: 2007/06/07 14:52:05 $

hF.FilterStructure = this.FilterStructure;

% [EOF]
