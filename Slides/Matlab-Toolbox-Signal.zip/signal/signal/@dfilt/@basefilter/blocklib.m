function [lib src] = blocklib(this)
%BLOCKLIB   

%   Author(s): R. Losada
%   Copyright 2006 The MathWorks, Inc.
%   $Revision: 1.1.6.2 $  $Date: 2007/12/14 15:07:20 $

error(generatemsgid('InternalError'),'This method must be overloaded.');


% [EOF]
