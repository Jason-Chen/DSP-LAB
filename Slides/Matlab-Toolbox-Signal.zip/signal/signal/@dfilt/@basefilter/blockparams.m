function s = blockparams(Hd, mapstates)
%BLOCKPARAMS Returns the parameters for BLOCK

% This should be a private method

% Author(s): V. Pellissier
% Copyright 1988-2006 The MathWorks, Inc.
% $Revision: 1.1.4.3 $ $Date: 2007/12/14 15:07:21 $

error(generatemsgid('NotSupported'),'Structure not supported.')

% [EOF]
