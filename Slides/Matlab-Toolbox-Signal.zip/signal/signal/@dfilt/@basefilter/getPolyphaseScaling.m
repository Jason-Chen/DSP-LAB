function polyphaseScaling = getPolyphaseScaling(this)
%GETPOLYPHASESCALING Get the polyphaseScaling.

%   Copyright 2008 The MathWorks, Inc.
%   $Revision: 1.1.4.1 $  $Date: 2008/08/04 19:50:47 $

polyphaseScaling = 1;

% [EOF]
