function str = getinfoheader(h)
%GETINFOHEADER Return the header to the info

%   Author: J. Schickler
%   Copyright 1988-2002 The MathWorks, Inc.
%   $Revision: 1.2 $  $Date: 2002/10/21 16:31:25 $

% Setup the title string
if isreal(h),
    typestr = 'real';
else
    typestr = 'complex';
end

if isfir(h),
    typestr = sprintf('FIR Filter (%s)', typestr);
else
    typestr = sprintf('IIR Filter (%s)', typestr);
end

str = sprintf('Discrete-Time %s',typestr);

% [EOF]
