function v = get_version(h, v)
%GET_VERSION   PreGet function for the 'version' property.

%   Author(s): P. Costa
%   Copyright 1988-2008 The MathWorks, Inc.
%   $Revision: 1.1.6.4 $  $Date: 2008/05/12 21:35:47 $

v.number      = 4;
v.description = 'R2008b';

% [EOF]
