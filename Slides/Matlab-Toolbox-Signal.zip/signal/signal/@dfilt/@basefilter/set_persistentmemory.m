function persistentmemory = set_persistentmemory(h, persistentmemory)
%SET_PERSISTENTMEMORY   PreSet function for the 'persistentmemory' property.

%   Author(s): V. Pellissier
%   Copyright 1988-2004 The MathWorks, Inc.
%   $Revision: 1.1.6.2 $  $Date: 2004/10/18 21:01:06 $


% [EOF]
