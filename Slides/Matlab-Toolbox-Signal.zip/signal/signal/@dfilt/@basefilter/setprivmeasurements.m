function setprivmeasurements(this, measurements)
%SETPRIVMEASUREMENTS   Set the privMeasurements.

%   Author(s): V. Pellissier
%   Copyright 2005 The MathWorks, Inc.
%   $Revision: 1.1.6.1 $  $Date: 2006/05/09 23:42:41 $

set(this, 'privMeasurements', measurements);

% [EOF]
