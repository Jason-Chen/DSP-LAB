function varargout = freqz(Hb,varargin)
%FREQZ  Discrete-time filter frequency response.
%   This method is obsolete.  Use FREQRESP instead.
%
%   See also DFILT, SIGNAL/FREQZ.

%   Author: V. Pellissier, J. Schickler Copyright 1988-2004 The MathWorks, Inc.
%   Inc.
%   $Revision: 1.4.4.3 $  $Date: 2005/06/16 08:17:38 $

% siguddutils('obsoletemethod', 'freqresp');

if nargout,
    [h,w] = base_resp(Hb, 'computefreqz', varargin{:});
    varargout = {h, w};
else,
    [Hb, opts] = freqzparse(Hb, varargin{:});
    fvtool(Hb, 'freq', opts);
end

% [EOF]
