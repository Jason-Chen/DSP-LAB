function constr = thisfiltquant_plugins(h,arith)
%FILTQUANT_PLUGINS Table of filterquantizer plugins

%   Author(s): V. Pellissier
%   Copyright 1999-2005 The MathWorks, Inc.
%   $Revision: 1.1.6.4 $  $Date: 2005/12/22 18:57:07 $

switch arith
    case 'custom',
        %#function quantum.customcalatticefilterq
        constr = 'quantum.customcalatticefilterq';
    case 'fixed',
        %#function quantum.dspfixedcalatticefilterq
        constr = 'quantum.dspfixedcalatticefilterq';
end
