function str = getcoupledsum(Hd)
%GETCOUPLEDSUM Return the value (string) of the summer that couple the
%all-pass filters.

% This should be a private method

%    Author: Don Orofino, V. Pellissier
%    Copyright 1988-2002 The MathWorks, Inc.
%    $Revision: 1.2 $  $Date: 2002/03/28 17:01:50 $

str = '|++';
