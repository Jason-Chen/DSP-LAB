function s = dispstr(Hd, varargin)
%DISPSTR Display string of coefficients.
%   DISPSTR(Hd) returns a string that can be used to display the coefficients
%   of discrete-time filter Hd.
%
%   See also DFILT.

%   Author: R. Losada
%   Copyright 1988-2005 The MathWorks, Inc.
%   $Revision: 1.2.4.8 $  $Date: 2007/08/03 21:39:47 $

[num_str, den_str, sv_str] = dispstr(Hd.filterquantizer, Hd.privnum, ...
    Hd.privden, Hd.privscalevalues, varargin{:});

sos_str = [num_str repmat('  ', nsections(Hd), 1) den_str];

s = char({xlate('SOS matrix:')
    sos_str
    ''
    xlate('Scale Values:')
    sv_str});

% [EOF]
