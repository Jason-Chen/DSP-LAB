function Hd = dispatch(this)
%DISPATCH   Dispatch to a light weight dfilt.

%   Author(s): J. Schickler
%   Copyright 2004 The MathWorks, Inc.
%   $Revision: 1.1.6.1 $  $Date: 2005/02/23 02:47:51 $

Hd = lwdfilt.sos(this.SOSMatrix, this.ScaleValues);

Hd.refSOSMatrix   = this.refsosMatrix;
Hd.refScaleValues = this.refScaleValues;

% [EOF]
