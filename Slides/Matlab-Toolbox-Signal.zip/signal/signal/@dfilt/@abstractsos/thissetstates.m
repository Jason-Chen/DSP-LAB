function S = thissetstates(Hd,S)
%THISSETSTATES Overloaded set for the States property.

% This should be a private method

%   Author: R. Losada
%   Copyright 1988-2005 The MathWorks, Inc.
%   $Revision: 1.1.6.6 $  $Date: 2005/12/22 18:56:46 $

if ~isempty(S),
    % Check data type, quantize if needed
    S = validatestates(Hd.filterquantizer, S);
    nsections = Hd.nsections;
    if rem(size(S,2), nsections)~=0,
        error(sprintf('The number of columns of the state matrix must be a multiple of %d.',nsections));
    end
	% Reshape to one column per channel	
	ns = 2*nsections;
    w=warning('off');
	ncols = prod(size(S))/ns;
    warning(w);
	S = reshape(S,ns,ncols);
end
Hd.hiddenstates = S;
