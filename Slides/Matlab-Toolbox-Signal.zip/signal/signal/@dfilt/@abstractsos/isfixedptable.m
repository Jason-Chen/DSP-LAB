function fixflag = isfixedptable(Hd)
%ISFIXEDPTABLE True is the structure has an Arithmetic field

%   Author(s): V. Pellissier
%   Copyright 1988-2003 The MathWorks, Inc.
%   $Revision: 1.1.6.1 $  $Date: 2003/12/06 16:00:33 $

fixflag = true;

% [EOF]
