function c = coefficientvariables(h)
%COEFFICIENTVARIABLES Coefficient Variables. 

%   This should be a private method.

%   Author(s): P. Costa
%   Copyright 1988-2003 The MathWorks, Inc.
%   $Revision: 1.1.6.2 $  $Date: 2004/04/12 23:52:06 $

c = {'SOS','G'};

% [EOF]
