function varargout = abstractsos(varargin)
%ABSTRACTSOS Second-order-section filter virtual class.
%   ABSTRACTSOS is a virtual class---it is never intended to be instantiated.
  

%   Copyright 1988-2003 The MathWorks, Inc.
%   $Revision: 1.2.4.3 $  $Date: 2007/12/14 15:07:06 $

error(generatemsgid('AbstractClass'),'This is an abstract class.');
