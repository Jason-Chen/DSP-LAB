function optimizesv = getoptimizesv(this, optimizesv)
%GETOPTIMIZESV Get the optimizesv.
%   OUT = GETOPTIMIZESV(ARGS) <long description>

%   Copyright 2008 The MathWorks, Inc.
%   $Revision: 1.1.6.1 $  $Date: 2008/05/12 21:35:41 $

optimizesv = this.privOptimizeScaleValues;

% [EOF]
