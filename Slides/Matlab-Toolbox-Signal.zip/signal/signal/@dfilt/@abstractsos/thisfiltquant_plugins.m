function constr = thisfiltquant_plugins(h,arith)
%FILTQUANT_PLUGINS Table of filterquantizer plugins

%   Author(s): R. Losada
%   Copyright 1988-2005 The MathWorks, Inc.
%   $Revision: 1.1.6.4 $  $Date: 2005/12/22 18:56:45 $

switch arith
    case 'custom',
        %#function quantum.sosfilterquantizer
        constr = 'quantum.sosfilterquantizer';
    case 'fixed',
        %#function quantum.sosdspfilterquantizer
        constr = 'quantum.sosdspfilterquantizer';
end
