function [f, offset] = multfactor(this)
%MULTFACTOR   

%   Author(s): V. Pellissier
%   Copyright 2005 The MathWorks, Inc.
%   $Revision: 1.1.6.1 $  $Date: 2005/08/20 13:25:00 $

f = [1 1];
offset = [0 0];

% [EOF]
