function labels = propnames(this)
%PROPNAMES   

%   Author(s): R. Losada
%   Copyright 2005 The MathWorks, Inc.
%   $Revision: 1.1.6.1 $  $Date: 2005/12/22 18:56:34 $

labels = fieldnames(this.AllpassCoefficients);

% [EOF]
