function this = abstractcascadeallpass %#ok
%ABSTRACTCASCADEALLPASS   Abstract constructor produces an error.

%   Author(s): R. Losada
%   Copyright 2005 The MathWorks, Inc.
%   $Revision: 1.1.6.1 $  $Date: 2005/11/18 14:23:13 $

error(generatemsgid('abstractClass'), ...
    'ABSTRACTCASCADEALLPASS is an abstract class.');

% [EOF]
