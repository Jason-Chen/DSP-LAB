function b = thisisstable(this)
%THISISSTABLE   True if the object is stable.

%   Author(s): V. Pellissier
%   Copyright 2005 The MathWorks, Inc.
%   $Revision: 1.1.6.1 $  $Date: 2007/05/23 19:12:33 $

b = true;

% [EOF]
