function realizemdl(Hd,varargin)
%REALIZEMDL Filter realization (Simulink diagram).
%     REALIZEMDL(Hd) automatically generates architecture model of filter
%     Hd in a Simulink subsystem block using individual sum, gain, and
%     delay blocks, according to user-defined specifications.
%
%     REALIZEMDL(Hd, PARAMETER1, VALUE1, PARAMETER2, VALUE2, ...) generates
%     the model with parameter/value pairs.
%
%    EXAMPLES:
%    Hd = farrow.linearfd;
%    realizemdl(Hd);
% 
%    Author(s): Don Orofino, V. Pellissier
%    Copyright 1988-2006 The MathWorks, Inc.
%    $Revision: 1.1.6.2 $  $Date: 2007/12/14 15:06:50 $

% Check if Simulink is installed
[b, errstr, errid] = issimulinkinstalled;
if ~b
    error(generatemsgid(errid), errstr);
end

% Parse inputs
hTar = uddpvparse('dspfwiztargets.dgtarget', varargin{:});

% Clear gains and delays
hTar.gains = [];
hTar.delays = [];

% Create model
specname = hTar.blockname;
pos = createmodel(hTar);

% Add SubSystem
% hsubsys = add_block('built-in/subsystem',hTar.system, 'Tag', 'FilterWizardSubSystem');
% % Restore position of the block
% set_param(hsubsys,'Position', pos);
% 
% % Display custom message when algebraic loops occur. (Recursive structures
% % don't support frames).
% set_param(hsubsys ,'ErrorFcn', 'dspFilterRealizedInBasicElemsAlgLoopErrFcnCallback');

% Generate filter architecture
DGDF = dgdfgen(Hd);   % method defined in each DFILT class

% Expand dg_dfilt structure into directed graph
DG = expandToDG(DGDF);

% Optimize directed graph for gain1, gain0, gainN1, delay chain and
% coverter chain
optimize_dg(hTar,DG,Hd.privArithmetic);

% Garbage Collection
DG = gc(DG);

% Generate mdl system
dg2mdl(DG,hTar,pos);

% Refresh connections
sys = hTar.system;
oldpos = get_param(sys, 'Position');
set_param(sys, 'Position', oldpos + [0 -5 0 -5]);
set_param(sys, 'Position', oldpos);
% Open system
opengeneratedmdl(hTar);

%------------------------------------------------------
function optimize_dg(hTar,DG,HdArithmetic)

optimize(DG,strcmpi(hTar.OptimizeOnes,'on'),strcmpi(hTar.OptimizeNegOnes,'on'),...
    strcmpi(hTar.OptimizeZeros,'on'),strcmpi(hTar.OptimizeDelayChains,'on'),HdArithmetic);


