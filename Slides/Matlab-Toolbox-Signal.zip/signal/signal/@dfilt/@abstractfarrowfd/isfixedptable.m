function fixflag = isfixedptable(Hd)
%ISFIXEDPTABLE True is the structure has an Arithmetic field

%   Copyright 2007 The MathWorks, Inc.
%   $Revision: 1.1.6.1 $  $Date: 2007/05/23 19:12:10 $

fixflag = true;

% [EOF]
