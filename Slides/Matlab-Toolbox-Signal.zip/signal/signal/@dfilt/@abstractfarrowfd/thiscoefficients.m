function c = thiscoefficients(this)
%THISCOEFFICIENTS   

%   Author(s): V. Pellissier
%   Copyright 2005 The MathWorks, Inc.
%   $Revision: 1.1.6.1 $  $Date: 2007/05/23 19:12:30 $

c = {this.Coefficients};

% [EOF]
