function setprivmeasurements(this, privmeasurements)
%SETPRIVMEASUREMENTS   Set the privmeasurements.

%   Author(s): V. Pellissier
%   Copyright 2005 The MathWorks, Inc.
%   $Revision: 1.1.6.1 $  $Date: 2007/05/23 19:12:26 $

% No Op. 
% measurements can't be stored because the Fractional Delay can changed.
% Therefore measurements need to be recomputed all the time.

% [EOF]
