function delay = get_delay(this, delay)
%GET_DELAY   PreGet function for the 'delay' property.

%   Author(s): V. Pellissier
%   Copyright 2006 The MathWorks, Inc.
%   $Revision: 1.1.6.1 $  $Date: 2007/05/23 19:12:08 $

delay = double(this.privfracdelay);

% [EOF]
