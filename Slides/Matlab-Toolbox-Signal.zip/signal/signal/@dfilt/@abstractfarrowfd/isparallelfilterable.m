function logi = isparallelfilterable(this)
%ISPARALLELFILTERABLE   

%   Author(s): R. Losada
%   Copyright 1988-2004 The MathWorks, Inc.
%   $Revision: 1.1.6.1 $  $Date: 2007/05/23 19:12:12 $

logi = true;

% [EOF]
