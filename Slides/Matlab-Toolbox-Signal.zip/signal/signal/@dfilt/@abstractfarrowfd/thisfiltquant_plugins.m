function constr = thisfiltquant_plugins(h,arith)
%FILTQUANT_PLUGINS Table of filterquantizer plugins

%   Author(s): M. Chugh
%   Copyright 2005-2006 The MathWorks, Inc.
%   $Revision: 1.1.6.1 $  $Date: 2007/05/23 19:12:31 $
%   Revised by M. Chugh 2005/08/11

%#function quantum.fixedfdfarrowfilterq
constr = 'quantum.fixedfdfarrowfilterq';
