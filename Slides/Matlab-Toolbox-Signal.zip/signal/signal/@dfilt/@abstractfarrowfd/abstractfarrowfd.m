function this = abstractfarrowfd %#ok
%ABSTRACTFARROWFD Abstract constructor produces an error
%   OUT = ABSTRACTFARROWFD(ARGS) <long description>

%   Copyright 2007 The MathWorks, Inc.
%   $Revision: 1.1.6.1 $  $Date: 2007/05/23 19:12:04 $

error(generatemsgid('abstractClass'), ...
    'ABSTRACTFARROWFD is an abstract class.');

% [EOF]
