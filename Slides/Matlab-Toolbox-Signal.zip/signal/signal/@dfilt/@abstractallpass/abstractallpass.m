function this = abstractallpass %#ok
%ABSTRACTALLPASS   Abstract constructor produces an error.

%   Author(s): R. Losada
%   Copyright 2005 The MathWorks, Inc.
%   $Revision: 1.1.6.1 $  $Date: 2005/11/18 14:22:55 $

error(generatemsgid('abstractClass'), ...
    'ABSTRACTALLPASS is an abstract class.');

% [EOF]
