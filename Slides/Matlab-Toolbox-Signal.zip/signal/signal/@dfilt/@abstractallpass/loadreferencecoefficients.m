function loadreferencecoefficients(this,s)
%LOADREFERENCECOEFFICIENTS   

%   Author(s): R. Losada
%   Copyright 2005 The MathWorks, Inc.
%   $Revision: 1.1.6.2 $  $Date: 2005/12/22 18:56:28 $

set(this, 'refallpasscoeffs', s.refallpasscoeffs);

% [EOF]
