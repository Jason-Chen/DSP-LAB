function realizemdl(Hd,varargin)
%REALIZEMDL Filter realization (Simulink diagram).
%     REALIZEMDL(Hd) automatically generates architecture model of filter
%     Hd in a Simulink subsystem block using individual sum, gain, and
%     delay blocks, according to user-defined specifications.
%
%     REALIZEMDL(Hd, PARAMETER1, VALUE1, PARAMETER2, VALUE2, ...) generates
%     the model with parameter/value pairs.
%
%    EXAMPLES:
%    [b,a] = butter(5,.5);
%    Hd = dfilt.df1(b,a);
% 
%    %#1 Default syntax:
%    realizemdl(Hd);
% 
%    %#2 Using parameter/value pairs:
%    realizemdl(Hd, 'Blockname', 'My Filter', 'OptimizeZeros', 'on');

%    Author(s): Don Orofino, V. Pellissier
%    Copyright 1988-2006 The MathWorks, Inc.
%    $Revision: 1.1.4.10 $  $Date: 2007/12/14 15:06:56 $

% Check if Simulink is installed
[b, errstr, errid] = issimulinkinstalled;
if ~b
    error(generatemsgid(errid), errstr);
end

% Parse inputs
hParam = uddpvparse('dspfwiz.parameter', ...
    {'dspfwiz.parameter', Hd}, varargin{:});
hTar = get(hParam, 'targetObj');

% Clear gains and delays
hTar.gains = [];
hTar.delays = [];

% Create model
specname = hTar.blockname;
pos = createmodel(hTar);

% Add SubSystem
hsubsys = add_block('built-in/subsystem',hTar.system, 'Tag', 'FilterWizardSubSystem');
% Restore position of the block
set_param(hsubsys,'Position', pos);

% Display custom message when algebraic loops occur. (Recursive structures
% don't support frames).
set_param(hsubsys ,'ErrorFcn', 'dspFilterRealizedInBasicElemsAlgLoopErrFcnCallback');

% Generate filter architecture
msg = mdlgen(Hd,hTar);   % method defined in each DFILT class

if ~isempty(msg),
    delete_block(hTar.system);
    error(generatemsgid('NotSupported'),msg);
else
    % Refresh connections
    sys = hTar.system;
    oldpos = get_param(sys, 'Position');
    set_param(sys, 'Position', oldpos + [0 -5 0 -5]);
    set_param(sys, 'Position', oldpos);
    
    % Optimisations
    try,
        optimize_mdl(hTar, Hd);
    catch,
    end
    
    % Open system
    opengeneratedmdl(hTar);
end

% -------------------------------------------------------------
function optimize_mdl(hTar, Hd)

% Optimize zero gains
if strcmpi(hTar.OptimizeZeros, 'on'),
     optimizezerogains(hTar, Hd);
end

% Optimize unity gains
if strcmpi(hTar.OptimizeOnes, 'on'),
     optimizeonegains(hTar, Hd);
end

% Optimize -1 gains
if strcmpi(hTar.OptimizeNegOnes, 'on'),
     optimizenegonegains(hTar, Hd);
end

% Optimise delay chains
if strcmpi(hTar.OptimizeDelayChains, 'on'),
    optimizedelaychains(hTar);
end

% [EOF]
