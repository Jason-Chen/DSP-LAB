function fq = get_filterquantizer(this, fq)
%GET_FILTERQUANTIZER   PreGet function for the 'filterquantizer' property.

%   Author(s): J. Schickler
%   Copyright 1988-2004 The MathWorks, Inc.
%   $Revision: 1.1.6.1 $  $Date: 2004/12/26 22:02:43 $

fq = get(this, 'privfilterquantizer');

% [EOF]
