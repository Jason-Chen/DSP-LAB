function constr = filtquant_plugins(h,arith)
%FILTQUANT_PLUGINS Table of filterquantizer plugins

%   Author(s): R. Losada
%   Copyright 1988-2005 The MathWorks, Inc.
%   $Revision: 1.1.6.4 $  $Date: 2005/12/22 18:56:38 $

switch arith
    case 'double',
        %#function dfilt.filterquantizer
        constr = 'dfilt.filterquantizer';
    case 'single',
        %#function quantum.singlefilterquantizer
        constr = 'quantum.singlefilterquantizer';
    case 'float',
        %#function quantum.floatfilterquantizer
        constr = 'quantum.floatfilterquantizer';
    otherwise,
        constr = thisfiltquant_plugins(h,arith);
end
