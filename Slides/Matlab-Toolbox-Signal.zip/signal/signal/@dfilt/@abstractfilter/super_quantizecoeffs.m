function super_quantizecoeffs(this, eventData)
%SUPER_QUANTIZECOEFFS 

%   Copyright 2007 The MathWorks, Inc.
%   $Revision: 1.1.6.1 $  $Date: 2007/08/03 21:39:46 $

set(this,'privMeasurements',[]);
quantizecoeffs(this);


% [EOF]
