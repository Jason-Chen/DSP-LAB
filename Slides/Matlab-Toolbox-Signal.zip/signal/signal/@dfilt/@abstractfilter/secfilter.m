function secfilter(Hm,varargin)
%SECFILTER Discrete-time filter.

%   Author: V. Pellissier
%   Copyright 1988-2002 The MathWorks, Inc.
%   $Revision: 1.1.4.1 $  $Date: 2007/12/14 15:06:58 $

error(generatemsgid('InternalError'),'The SECFILTER method must be overloaded.');

% [EOF]
