function n = naddp1(h)
%NADDP1   

%   Author(s): R. Losada
%   Copyright 1988-2004 The MathWorks, Inc.
%   $Revision: 1.1.6.1 $  $Date: 2004/07/28 04:36:24 $

n = h.ncoeffs;

% [EOF]
