function check_if_optimizezeros_possible(this, hTar)
%CHECK_IF_OPTIMIZEZEROS_POSSIBLE   

%   Author(s): V. Pellissier
%   Copyright 2006 The MathWorks, Inc.
%   $Revision: 1.1.6.1 $  $Date: 2006/06/11 17:30:35 $

% No op.

% [EOF]
