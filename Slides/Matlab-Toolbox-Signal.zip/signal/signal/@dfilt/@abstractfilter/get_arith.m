function arith = get_arith(q, arith)
%GET_ARITH   PreGet function for the Arithmetic property.

%   Author(s): V. Pellissier
%   Copyright 1988-2004 The MathWorks, Inc.
%   $Revision: 1.1.6.1 $  $Date: 2004/03/15 22:26:13 $

arith = q.privArithmetic;

% [EOF]
