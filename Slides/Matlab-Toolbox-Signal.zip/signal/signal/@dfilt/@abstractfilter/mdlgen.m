function msg = mdlgen(Hd, hTar, Hq)
%MDLGEN Simulink filter generator.

%    This should be a private method

%    Author(s): Don Orofino, V. Pellissier
%    Copyright 1988-2002 The MathWorks, Inc.
%    $Revision: 1.1.4.1 $  $Date: 2007/12/14 15:06:55 $

error(nargchk(2,3,nargin,'struct'));
msg = 'Structure not supported.';

% [EOF]
