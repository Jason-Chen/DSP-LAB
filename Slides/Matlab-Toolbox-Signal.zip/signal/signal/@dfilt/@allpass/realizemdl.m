function realizemdl(Hd,varargin)
%REALIZEMDL Filter realization (Simulink diagram).
%     REALIZEMDL(Hd) automatically generates architecture model of filter
%     Hd in a Simulink subsystem block using individual sum, gain, and
%     delay blocks, according to user-defined specifications.
%
%     REALIZEMDL(Hd, PARAMETER1, VALUE1, PARAMETER2, VALUE2, ...) generates
%     the model with parameter/value pairs.
%
%    EXAMPLES:
%    [b,a] = butter(5,.5);
%    Hd = dfilt.df1(b,a);
% 
%    %#1 Default syntax:
%    realizemdl(Hd);
% 
%    %#2 Using parameter/value pairs:
%    realizemdl(Hd, 'Blockname', 'My Filter', 'OptimizeZeros', 'on');

%    Author(s): Don Orofino, V. Pellissier
%    Copyright 1988-2006 The MathWorks, Inc.
%    $Revision: 1.1.6.5 $  $Date: 2007/12/14 15:07:16 $

% Check if Simulink is installed
[b, errstr, errid] = issimulinkinstalled;
if ~b
    error(generatemsgid(errid), errstr);
end

% Limited support for AllpassCoefficients
c = coeffs(Hd);
if isempty(find(length(c.AllpassCoefficients)==[0 1 2 4])),
    error(generatemsgid('InvalidCoeffs'), ...
        'The length of the AllpassCoefficients vector must be 0, 1, 2 or 4.');
end

% Error out if 
% Parse inputs
hTar = uddpvparse('dspfwiztargets.dgtarget', varargin{:});

% Clear gains and delays
hTar.gains = [];
hTar.delays = [];

% Create model
specname = hTar.blockname;
pos = createmodel(hTar);

if strcmpi(Hd.privArithmetic, 'fixed') && strcmpi(Hd.RoundMode, 'Round'),
    warning('DSPBLKS:realizemdl:RoundModeChanged', ...
        'Round rounding is not supported in Simulink. Nearest rounding will be used instead.');
end

% Generate filter architecture
DGDF = dgdfgen(Hd);   % method defined in each DFILT class

% Expand dg_dfilt structure into directed graph
DG = expandToDG(DGDF);

% Optimize directed graph for gain1, gain0, gainN1, delay chain and
% coverter chain
optimize_dg(hTar,DG,Hd.privArithmetic);

% Garbage Collection
DG = gc(DG);

% Generate mdl system
dg2mdl(DG,hTar,pos);

% Refresh connections
sys = hTar.system;
oldpos = get_param(sys, 'Position');
set_param(sys, 'Position', oldpos + [0 -5 0 -5]);
set_param(sys, 'Position', oldpos);
% Open system
opengeneratedmdl(hTar);

%------------------------------------------------------
function optimize_dg(hTar,DG,HdArithmetic)

optimize(DG,strcmpi(hTar.OptimizeOnes,'on'),strcmpi(hTar.OptimizeNegOnes,'on'),...
    strcmpi(hTar.OptimizeZeros,'on'),strcmpi(hTar.OptimizeDelayChains,'on'),HdArithmetic);


