function realizeflag = isrealizable(Hd)
%ISREALIZABLE True if the structure can be realized by simulink

%   Author(s): Honglei Chen
%   Copyright 1988-2005 The MathWorks, Inc.
%   $Revision: 1.1.6.1 $  $Date: 2005/12/22 18:56:50 $

realizeflag = true;
c = coeffs(Hd);
if isempty(find(length(c.AllpassCoefficients)==[0 1 2 4])),
    realizeflag = false;
end

% [EOF]
