function DGDF = dgdfgen(Hd)
%DGDFGEN generate the dg_dfilt structure from a specified filter structure
%Hd.

%   Author(s): Honglei Chen
%   Copyright 1988-2005 The MathWorks, Inc.
%   $Revision: 1.1.6.2 $  $Date: 2005/12/22 18:56:49 $


DGDF=allpassdgdfgen(Hd.filterquantizer,Hd);

