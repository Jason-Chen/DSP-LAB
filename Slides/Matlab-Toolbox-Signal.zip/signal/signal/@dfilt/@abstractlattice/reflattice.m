function n = reflattice(h)
%REFLATTICE Return reference Lattice.

%   Author(s): V. Pellissier
%   Copyright 1988-2003 The MathWorks, Inc.
%   $Revision: 1.1.6.1 $  $Date: 2003/04/11 18:38:40 $

n = h.reflattice;

