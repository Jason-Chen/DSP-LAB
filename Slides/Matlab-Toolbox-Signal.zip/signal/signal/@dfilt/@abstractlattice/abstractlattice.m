function Hd = abstractlattice(varargin)
%ABSTRACTLATTICE Constructor for this class.

%   Author: V. Pellissier
%   Copyright 1988-2003 The MathWorks, Inc.
%   $Revision: 1.1.6.2 $  $Date: 2007/12/14 15:07:05 $

error(generatemsgid('AbstractClass'),'This is an abstract class.');

% [EOF]
