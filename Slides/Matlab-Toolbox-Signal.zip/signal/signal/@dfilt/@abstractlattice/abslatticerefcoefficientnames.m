function rcnames = abslatticerefcoefficientnames(this)
%ABSLATTICEREFCOEFFICIENTNAMES   

%   Author(s): R. Losada
%   Copyright 2003 The MathWorks, Inc.
%   $Revision: 1.1.6.1 $  $Date: 2003/12/06 15:59:59 $

rcnames = {'reflattice'};

% [EOF]
