function constr = thisfiltquant_plugins(h,arith)
%FILTQUANT_PLUGINS Table of filterquantizer plugins

%   Author(s): V. Pellissier
%   Copyright 1999-2005 The MathWorks, Inc.
%   $Revision: 1.1.6.5 $  $Date: 2005/12/22 18:56:42 $

switch arith
    case 'fixed',
        %#function quantum.fixedlatticefilterq
        constr = 'quantum.fixedlatticefilterq';
end
